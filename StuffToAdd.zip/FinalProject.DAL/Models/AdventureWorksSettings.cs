﻿namespace FinalProject.DAL.Models
{
	public class AdventureWorksSettings
	{
		public string categoryUri { get; set; } = string.Empty;
		public string productsUri { get; set; } = string.Empty;
		public string suppliersUri { get; set; } = string.Empty;

	}
}
